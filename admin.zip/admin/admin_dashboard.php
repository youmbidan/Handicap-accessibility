<?php
session_start();

if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Administrateur</title>
</head>
<body>
    <h2>Tableau de bord Administrateur</h2>
    <ul>
        <li><a href="manage_users.php">Gérer les Utilisateurs</a></li>
        <li><a href="manage_products.php">Gérer les Produits</a></li>
        <li><a href="logout.php">Se déconnecter</a></li>
    </ul>
</body>
</html>
