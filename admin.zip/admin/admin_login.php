<?php
session_start();

if(isset($_SESSION['admin_id'])) {
    header("Location: admin_dashboard.php");
    exit;
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérification des informations d'identification de l'administrateur
    $admin_username = "admin"; // Nom d'utilisateur de l'administrateur
    $admin_password = "password"; // Mot de passe de l'administrateur

    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    if($input_username === $admin_username && $input_password === $admin_password) {
        $_SESSION['admin_id'] = 1; // Identifiant de session pour l'administrateur
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error = "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Administrateur</title>
</head>
<body>
    <h2>Connexion Administrateur</h2>
    <form method="post">
        <label for="username">Nom d'utilisateur:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password">Mot de passe:</label><br>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Se connecter">
    </form>
    <?php if(isset($error)) { echo "<p>$error</p>"; } ?>
</body>
</html>
