# handicap_access/controllers/controllers.py

from odoo import http#type:ignore
from odoo.http import request#type:ignore

import logging

_logger = logging.getLogger(__name__)

class HandicapAccessController(http.Controller):

    @http.route('/handicap_access/homepage', type='http', auth='public')
    def homepage(self, **kw):
        return request.render('handicap.homepage_template')
    
    # Dans votre fichier Python (handicap_access/controllers/controllers.py)

   
    @http.route('/handicap_access/submit_form', type='http', auth='public', methods=['POST'])
    def submitForm(self, **post):
        _logger.info("Received form data: %s", post)
    
        try:
            if post:
                nom = post.get('nom')
                prenom = post.get('prenom')
                email = post.get('email')
                password = post.get('password')
                type_handicap_name = post.get('type_handicap_id')
                
                 

                # Rechercher l'identifiant correspondant au type de handicap
                handicap_model = request.env['handicap_access.handicap']
                type_handicap_record = handicap_model.search([('name', '=', type_handicap_name)], limit=1)
                _logger.info("Handicap record found: %s", type_handicap_record)

                if not type_handicap_record:
                    _logger.error("No handicap record found for: %s", type_handicap_name)
                    return request.redirect('/handicap_access/homepage')

                type_handicap_id = type_handicap_record.id

                # Enregistrer l'utilisateur
                user_model = request.env['handicap_access.utilisateur']
                new_user = user_model.create({
                    'nom': nom,
                    'prenom': prenom,
                    'email': email,
                    'password': password,
                    'type_handicap_id': type_handicap_id,
                })
                _logger.info("New user created: %s", new_user)

                # Appliquer la personnalisation
                self.apply_customization(type_handicap_id, new_user.id)

                # Rediriger l'utilisateur vers le site web généré par Odoo
                website_url = self._get_website_url()
                return request.redirect('http://localhost:8069/')

            else:
                _logger.error("Form submitted without data")
                return request.redirect('/handicap_access/homepage')
        except Exception as e:
            _logger.exception("An error occurred while processing the form: %s", e)
            return request.redirect('/handicap_access/homepage')

    def _get_website_url(self):
        # Implémentez cette fonction pour récupérer l'URL de votre site web généré par Odoo
        # Vous pouvez obtenir cette URL à partir des paramètres de configuration ou de toute autre source
        # Par exemple, si vous avez un modèle de configuration pour stocker l'URL du site web :
        # website_config = request.env['your.website.config.model'].sudo().search([], limit=1)
        # return website_config.website_url
        # Pour cet exemple, j'ai simplement supposé que vous avez l'URL codée en dur
        return 'http://localhost:8069/'

    def apply_customization(self, type_handicap_id, utilisateur_id):
        # Récupérer les paramètres de personnalisation correspondant au type de handicap de l'utilisateur
        personnalisations = request.env['handicap_access.personnalisation'].search([
            ('type_handicap_id', '=', type_handicap_id), 
            ('utilisateur_id', '=', utilisateur_id)
        ], limit=1)
        
        if personnalisations:
            utilisateur = request.env['handicap_access.utilisateur'].browse(utilisateur_id)
            if personnalisations.audio_description:
                # Activer l'audio description sur votre site web
                utilisateur.write({'audio_description': True})
            if personnalisations.reconnaissance_vocale:
                # Activer la reconnaissance vocale sur votre site web
                utilisateur.write({'reconnaissance_vocale': True})
            if personnalisations.ajustement_couleur:
                # Activer l'ajustement de couleur sur votre site web
                utilisateur.write({'ajustement_couleur': True})
            if personnalisations.ajustement_contraste:
                # Activer l'ajustement de contraste sur votre site web
                utilisateur.write({'ajustement_contraste': True})
            if personnalisations.ajustement_taille_police:
                # Activer l'ajustement de la taille de police sur votre site web
                utilisateur.write({'ajustement_taille_police': True})

    # Ajouter une méthode qui peut être appelée sans paramètres
def delete_user_without_params(self):
    user_id = request.env.user.id  # Suppose que vous utilisez l'utilisateur courant
    return self.delete_user(user_id=user_id)

@http.route('/handicap_access/delete_user', type='http', auth='user')
def delete_user(self, user_id):
    try:
        utilisateur_model = request.env['handicap_access.utilisateur']
        utilisateur_model.unlink_user(user_id)
        return request.redirect('/handicap_access/homepage')
    except Exception as e:
        _logger.exception("An error occurred while deleting the user record: %s", e)
        return request.redirect('/handicap_access/homepage')
    