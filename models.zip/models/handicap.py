from odoo import models, fields, api # type: ignore
from odoo.exceptions import ValidationError #type:ignore

class Handicap(models.Model):
    _name = 'handicap_access.handicap'
    _description = 'Handicap'
    
    name = fields.Char(string='Nom', required=True)
    type = fields.Selection([
        ('aveugle', 'Aveugle'),
        ('malvoyant', 'Malvoyant'),
        ('sourd', 'Sourd'),
        ('normal', 'Normal')
        
    ], string='Type de Handicap', required=True)
    description = fields.Text(string='Description', required=True)
   

    @api.model
    def createType(self, type, description):
        """Créer un nouveau type de handicap"""
        if self.search([('type', '=', type)]):
            raise ValidationError("Un type de handicap avec ce nom existe déjà.")
        new_type = self.create({
            'type': type,
            'description': description
        })
        return new_type

    def updateType(self, type=None, description=None):
        """Mettre à jour le type de handicap"""
        if type and self.search([('type', '=', type), ('id', '!=', self.id)]):
            raise ValidationError("Un type de handicap avec ce nom existe déjà.")
        
        update_data = {}
        if type:
            update_data['type'] = type
        if description:
            update_data['description'] = description
        
        self.write(update_data)
        return True

    @api.model
    def getUsersWithDisability(self, type_handicap_id):
        """Obtenir les utilisateurs avec un type de handicap spécifique"""
        users = self.env['handicap_access.utilisateur'].search([('type_handicap_id.type', '=', type_handicap_id)])
        return users
