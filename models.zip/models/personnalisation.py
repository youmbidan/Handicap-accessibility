from odoo import models, fields, api#type:ignore
from odoo.exceptions import ValidationError#type:ignore


import os

from gtts import gTTS #type:ignore

from playsound import playsound #type:ignore



class Personnalisation(models.Model):
    _name = 'handicap_access.personnalisation'
    _description = 'Personnalisation'

    type_handicap_id = fields.Many2one('handicap_access.handicap', string='Type de Handicap')
    utilisateur_id = fields.Many2one('handicap_access.utilisateur', string='Utilisateur')
    audio_description = fields.Boolean(string='Audio Description')
    reconnaissance_vocale = fields.Boolean(string='Reconnaissance Vocale')
    ajustement_couleur = fields.Boolean(string='Ajustement de Couleur')
    ajustement_contraste = fields.Boolean(string='Ajustement de Contraste')
    ajustement_taille_police = fields.Boolean(string='Ajustement de Taille de Police')

    @api.model
    def generate_audio_description(self, text):
        """Generates an audio description for the provided text."""
        tts = gTTS(text, lang='fr')  # Assumes the text is in French
        file_path = '/tmp/audio_description.mp3'
        tts.save(file_path)
        playsound(file_path)
        os.remove(file_path)
        
   

    @api.model
    def applyCustomization(self, type_handicap_id, utilisateur_id):
        """Applique la personnalisation pour un utilisateur donné et un type de handicap donné"""
        customization = self.search([('type_handicap_id', '=', type_handicap_id), ('utilisateur_id', '=', utilisateur_id)], limit=1)
        if customization:
            utilisateur = self.env['handicap_access.utilisateur'].browse(utilisateur_id)
            if customization.audio_description and type_handicap_id.type == 'aveugle':
                text_to_describe = "Le texte que vous souhaitez décrire."  # Replace this with the actual text to describe
                self.generate_audio_description(text_to_describe)
            if customization.reconnaissance_vocale and type_handicap_id.type == 'aveugle':
                utilisateur.write({'reconnaissance_vocale': True})
            if customization.ajustement_couleur and type_handicap_id.type == 'Malvoyant':
                utilisateur.write({'ajustement_couleur': True})
            if customization.ajustement_contraste and type_handicap_id.type == 'Malvoyant':
                utilisateur.write({'ajustement_contraste': True})
            if customization.ajustement_taille_police and type_handicap_id.type == 'Malvoyant':
                utilisateur.write({'ajustement_taille_police': True})
            return True
        return False
    
    
    
    @api.model
    def get_user_customizations(self):
        user_id = self.env.user.id
        customization = self.search([('utilisateur_id', '=', user_id)], limit=1)
        if customization:
            
            if customization.type_handicap_id.type == 'malvoyant':
                return {
                    'type_handicap_id': 'malvoyant',  # Ajoutez cette ligne pour indiquer le type de handicap
                    'ajustement_couleur': customization.ajustement_couleur,
                    'ajustement_contraste': customization.ajustement_contraste,
                    'ajustement_taille_police': customization.ajustement_taille_police,
                }
       
        return {}


    @api.model
    def createCustomization(self, type_handicap_id, utilisateur_id, audio_description=False, reconnaissance_vocale=False, ajustement_couleur=False, ajustement_contraste=False, ajustement_taille_police=False):
        """Crée une personnalisation pour un utilisateur donné et un type de handicap donné"""
        type_handicap_id = self.env['handicap_access.handicap'].browse(type_handicap_id)
        if audio_description and type_handicap_id.type != 'aveugle':
            raise ValidationError("L'audio description ne peut être activée que pour le type de handicap 'Aveugle'.")
        if reconnaissance_vocale and type_handicap_id.type != 'aveugle':
            raise ValidationError("La reconnaissance vocale ne peut être activée que pour le type de handicap 'Aveugle'.")
        if (ajustement_couleur or ajustement_contraste or ajustement_taille_police) and type_handicap_id.type != 'Malvoyant':
            raise ValidationError("Les ajustements de couleur, contraste et taille de police ne peuvent être activés que pour le type de handicap 'Malvoyant'.")
        
        customization = self.create({
            'type_handicap_id': type_handicap_id,
            'utilisateur_id': utilisateur_id,
            'audio_description': audio_description,
            'reconnaissance_vocale': reconnaissance_vocale,
            'ajustement_couleur': ajustement_couleur,
            'ajustement_contraste': ajustement_contraste,
            'ajustement_taille_police': ajustement_taille_police,
        })
        # Appliquer la personnalisation pour l'utilisateur nouvellement créé
        self.applyCustomization(type_handicap_id, utilisateur_id)
        return customization

    @api.model
    def updateCustomization(self, type_handicap_id, utilisateur_id, audio_description=False, reconnaissance_vocale=False, ajustement_couleur=False, ajustement_contraste=False, ajustement_taille_police=False):
        """Met à jour la personnalisation pour un utilisateur donné et un type de handicap donné"""
        customization = self.search([('type_handicap_id', '=', type_handicap_id), ('utilisateur_id', '=', utilisateur_id)], limit=1)
        if customization:
            customization.write({
                'audio_description': audio_description,
                'reconnaissance_vocale': reconnaissance_vocale,
                'ajustement_couleur': ajustement_couleur,
                'ajustement_contraste': ajustement_contraste,
                'ajustement_taille_police': ajustement_taille_police,
            })
            # Appliquer les nouvelles paramètres de personnalisation
            self.applyCustomization(type_handicap_id, utilisateur_id)
            return True
        return False

    @api.model
    def removeCustomization(self, type_handicap_id, utilisateur_id):
        """Supprime la personnalisation pour un utilisateur donné et un type de handicap donné"""
        customization = self.search([('type_handicap_id', '=', type_handicap_id), ('utilisateur_id', '=', utilisateur_id)], limit=1)
        if customization:
            customization.unlink()
            # Réinitialiser les paramètres de personnalisation à leurs valeurs par défaut
            utilisateur = self.env['handicap_access.utilisateur'].browse(utilisateur_id)
            utilisateur.write({
                'audio_description': False,
                'reconnaissance_vocale': False,
                'ajustement_couleur': False,
                'ajustement_contraste': False,
                'ajustement_taille_police': False,
            })
            return True
        return False
