from odoo import models, fields, api#type:ignore
from odoo.exceptions import ValidationError#type:ignore

class Utilisateur(models.Model):
    _name = 'handicap_access.utilisateur'
    _description = 'Utilisateur'
    _sql_constraints = [
        ('email_unique', 'unique(email)', 'Un utilisateur avec cet email existe déjà.')
    ]

    nom = fields.Char(string='Nom', required=True)
    prenom = fields.Char(string='Prenom', required=True)
    email = fields.Char(string='Email', required=True)
    password = fields.Char(string='Password', required=True)
    type_handicap_id = fields.Many2one('handicap_access.handicap', string='Type de Handicap')

    @api.model
    def register(self, nom, prenom, email, password, type_handicap_id):
        """Méthode pour enregistrer un nouvel utilisateur"""
        if self.search([('email', '=', email)]):
            raise ValidationError("Un utilisateur avec cet email existe déjà.")
        
        user_data = {
            'nom': nom,
            'prenom': prenom,
            'email': email,
            'password': password,
            'type_handicap_id': type_handicap_id,
        }
        new_user = self.create(user_data)
        return new_user

    @api.model
    def login(self, email, password):
        """Méthode pour connecter un utilisateur"""
        user = self.search([('email', '=', email), ('password', '=', password)], limit=1)
        if not user:
            raise ValidationError("Email ou mot de passe incorrect.")
        return user

    def update_profile(self, nom=None, prenom=None, email=None, password=None, type_handicap_id=None):
        """Méthode pour mettre à jour le profil de l'utilisateur"""
        if email and self.search([('email', '=', email), ('id', '!=', self.id)]):
            raise ValidationError("Un utilisateur avec cet email existe déjà.")
        
        update_data = {}
        if nom:
            update_data['nom'] = nom
        if prenom:
            update_data['prenom'] = prenom
        if email:
            update_data['email'] = email
        if password:
            update_data['password'] = password
        if type_handicap_id:
            update_data['type_handicap_id'] = type_handicap_id
        
        self.write(update_data)
        return True

    def get_preferences(self):
        """Méthode pour obtenir les préférences de l'utilisateur"""
        preferences = {
            'nom': self.nom,
            'prenom': self.prenom,
            'email': self.email,
            'password': self.password,
            'type_handicap_id': self.type_handicap_id.id if self.type_handicap_id else None,
        }
        return preferences

    @api.model
    def submit_form(self, values):
        """Méthode pour soumettre le formulaire de la page d'accueil"""
        # Extraire les données du dictionnaire values
        nom = values.get('nom')
        prenom = values.get('prenom')
        email = values.get('email')
        password = values.get('password')
        type_handicap_id = values.get('type_handicap_id')

        # Appeler la méthode register pour enregistrer le nouvel utilisateur
        self.register(nom, prenom, email, password, type_handicap_id)

        # Rafraîchir la vue liste des utilisateurs pour refléter les changements
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    @api.model
    def delete_user(self, user_id):
        """Méthode pour supprimer un utilisateur"""
        user = self.browse(user_id)
        if user:
            user.unlink()
            return True
        return False
